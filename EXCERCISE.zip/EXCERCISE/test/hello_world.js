var helloworld = artifacts.require('HelloWorld');
contract('HelloWorld', function(accounts) {
  let instance;
  before(async () => {
    instance = await helloworld.deployed();
  });
  it('Default message should be hello world',async () => {
    let message = await instance.getMessage.call({from: accounts[0]});           
    assert.equal(message, "Hello World","Incorrect message.");
  });

  before(async () => {
    instance = await helloworld.deployed();
  });

  it('Set name to Hiren for Account 1 and Validte Hellow Message',async () => {
    await instance.setName("Hiren",{from:accounts[1]});
    let message = await instance.getMessage.call({from: accounts[1]});           
    assert.equal(message, "Hello Hiren","Incorrect message.");
  });
});