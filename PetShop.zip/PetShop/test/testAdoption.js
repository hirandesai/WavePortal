const adoptionArtifact = artifacts.require("Adoption");

contract("Adoption",(accounts)=>{
let adoption;
let expectedAdopter;

    before(async()=>{
        adoption =  await adoptionArtifact.deployed();
    })

    describe("adopting a pet and retriving the account address",async()=>{
    before("adopting a pet account [0]", async()=>{
        await adoption.adopt(8,{from:accounts[0]});
        expectedAdopter =   accounts[0];

    });
    it("can fetch the address of an owner by pet id", async () => {
        const adopters = await adoption.getAdopters();
        assert.equal(adopters[8], expectedAdopter, "The owner of the adopted pet should be the first account.");
    });
    });

});