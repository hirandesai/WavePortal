var adoptionMigration = artifacts.require("./Adoption.sol");

module.exports = function(deployer) {
  deployer.deploy(adoptionMigration);
};
